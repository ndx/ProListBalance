
/*
 * Copyright (C) Niklaus F.Schen.
 */

#ifndef __PL_DAEMON
#define __PL_DAEMON

void pl_init_daemon(void);
#endif

