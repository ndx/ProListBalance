
/*
 * Copyright (C) Niklaus F.Schen.
 */

/*
functions:
	pl_init_server() pl_create_server_node()
	pl_mount_server_node() pl_set_server_node()
	pl_del_server_node() pl_get_server_node()
	pl_call_algorithm()	pl_set_server_idle()
	pl_get_server_list() pl_set_algorithm()
Attention:
	pl_get_server_node() will return NULL, if it
	doesn't find out the specific item or the
	parameter 'str' is NULL.
*/

#ifndef __PL_SERVER
#define __PL_SERVER

#include"pl_types.h"
#include"pl_alloc.h"
#include"pl_statistics.h"
#include<sys/socket.h>
#include<netinet/in.h>
#include<arpa/inet.h>

#define NAME 256
#define IPLEN 32
/*#define for load balancing algorithms*/
#define NRALG 2
#define ROUNDROBIN 0
#define IPHASH 1

typedef struct pl_server_s {
	pl_char_t srvname[NAME];
	pl_char_t ip[IPLEN];
	pl_ushort_t port;
	pl_statinfo_t info;
	void *socklist;
	void *socktail;
	struct pl_server_s *next;
	struct pl_server_s *prev;
}pl_server_t;

typedef struct pl_srvlist_s {
	pl_server_t *ps;
	pl_server_t *ps_tail;
	pl_pool_t *pool;
}pl_srvlist_t;

typedef struct pl_algorithm_data_s {
	struct sockaddr_in addr;
}pl_algorithm_data_t;

typedef pl_server_t *(*pl_algorithm)\
		(pl_server_t *srvlist, \
		pl_algorithm_data_t *data);



void pl_init_server(void);
pl_server_t *pl_create_server_node(void);
void pl_mount_server_node(pl_server_t *ps);
void pl_set_server_node(pl_server_t *ps, \
		const pl_char_t *srvname, \
		const pl_char_t *ip, \
		pl_ushort_t port, \
		pl_int_t weight, \
		pl_int_t down);
void pl_del_server_node(pl_server_t *ps);
pl_server_t *
pl_get_server_node(const pl_char_t *str, \
			pl_ushort_t port);
pl_int_t pl_get_nr_server(void);
void pl_set_server_idle(void);
pl_server_t *pl_get_server_list(void);
/*for load balancing algorithm*/
pl_server_t *pl_call_algorithm(void *data);
pl_int_t pl_set_algorithm(const pl_char_t *alname);
/*void pl_print_server(void);*/
#endif

