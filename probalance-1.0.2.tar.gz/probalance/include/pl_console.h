
/*
 * Copyright (C) Niklaus F.Schen.
 */

#ifndef __PL_CONSOLE
#define __PL_CONSOLE

#include"pl_types.h"
#include"pl_statistics.h"

#define PACKLEN 1024
#define LOGIN 0xffff
#define COMMU 0x10000
#define STRLEN 256
#define UP 0x1111
#define ON UP
#define DOWN 0xffff
#define OFF DOWN
#define IPADDR 32
#define NR_CMD 18

/*global definitions*/
#define SERVER 14
#define CLIENT 15
/*private definitions*/
#ifdef __CONSOLE
#define BLOCKARG 17
#define BLOCKSTR 256
#define BUFLEN 1024
#define COLUME 32
#ifndef DENY
#define DENY 0x800000
#endif
#ifndef ALLOW
#define ALLOW 0x400000
#endif
/*commands*/
#define HELP 0
#define VERSION 1
#define QUIT 2
#define CLEAR 3
#define TURNSRV 4
#define TURNACL 5
#define ADDSRV 6
#define DELSRV 7
#define ADDACL 8
#define DELACL 9
#define SETSRV 10
#define SETACL 11
#define ACCESS 12
#define SETLBA 13
#define ADDPROC 16
#define TURNRESTART 17

typedef struct pl_chain_s {
	void *buf;
	pl_int_t size;
	pl_int_t w_size;
	struct pl_chain_s *next;
}pl_chain_t;

typedef struct pl_sum_info_s {
	pl_statinfo_t info;
	struct pl_sum_info_s *next;
}pl_sum_info_t;

#endif

typedef struct pl_console_package_s {
	pl_int_t cmd;
	pl_int_t status;	/*netbits for command addscl and setacl*/
	pl_int_t value;		/*weight for server and num for acl*/
	pl_ushort_t port;
	pl_char_t ip[IPADDR];
	pl_char_t param[STRLEN];	/*servername or load balancing algorithm*/
}pl_console_package_t;

#endif

