
/*
 * Copyright (C) Niklaus F.Schen.
 */

#ifndef __PL_LOG
#define __PL_LOG
#include"pl_types.h"

#define DEBUG 255
#define ERROR 1
#define EMERGE 0
#define LOGBUFLEN 1024

void pl_init_log(void);
void pl_log(pl_int_t prio, pl_char_t *fmt, ...);
#endif

