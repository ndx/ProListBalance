
/*
 * Copyright (C) Niklaus F.Schen.
 */

#ifndef __PL_SYSLIMIT
#define __PL_SYSLIMIT

#include"pl_types.h"

void pl_init_sysresource(void);
pl_int_t pl_get_work_connections(void);
#endif

