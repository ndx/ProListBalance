
/*
 * Copyright (C) Niklaus F.Schen.
 */

/*
functions:
	pl_fork() pl_fork_child() pl_create_proc()
	pl_mount_proc() pl_set_proc() pl_del_proc()
	pl_get_proc_type() pl_get_proc_lock()
	pl_get_nr_proc() pl_del_proc_node_socket()
	pl_get_pair_sockfd() pl_get_proc_list()
	pl_set_nr_proc() pl_get_autoadjust()
	pl_get_maxnrproc()
*/

#ifndef __PL_FORK
#define __PL_FORK

#include"pl_types.h"
#include"pl_socket.h"

#define MASTER 0xffffffff
#define WORKER 0x4000

typedef struct pl_proc_s {
	pl_int_t no_cpu;
	pl_pid_t pid;
	pl_socket_t *ps;
	struct pl_proc_s *next;
	struct pl_proc_s *prev;
}pl_proc_t;

typedef struct pl_proclist_s {
	pl_int_t type;
	pl_int_t nr_cpu;
	pl_int_t nr_proc;
	pl_int_t max_nr_proc;
	pl_int_t autoadjust;
	pl_proc_t *pp;
	pl_proc_t *pp_tail;
	pl_pool_t *pool;
}pl_proclist_t;

void pl_fork(pl_char_t *argv[]);
pl_int_t pl_fork_child(pl_char_t *argv[]);
/*proc*/
pl_proc_t *pl_create_proc(void);
void pl_mount_proc(pl_proc_t *pp);
void pl_set_proc(pl_proc_t *pp, \
		pl_int_t no_cpu, \
		pl_int_t pairfd, \
		pl_pid_t pid);
void pl_del_proc(pl_proc_t *pp);
pl_int_t pl_get_proc_type(void);
pl_int_t *pl_get_proc_lock(void);
pl_int_t pl_get_nr_proc(void);
void pl_set_nr_proc(pl_int_t num);
void pl_del_proc_node_socket(pl_socket_t *ps);
pl_socket_t *pl_get_pair_sockfd(pl_int_t fd);
pl_proc_t *pl_get_proc_list(void);
pl_int_t pl_get_autoadjust(void);
pl_int_t pl_get_maxnrproc(void);

/*void pl_print_fork(void);*/
#endif

