
/*
 * Copyright (C) Niklaus F.Schen.
 */

#include"pl_str.h"
#include"string.h"
#include"strings.h"
#include"stdlib.h"

pl_char_t **pl_slice(pl_char_t *str, \
    pl_int_t nr_arg, .../*, (char *)0*/)
{
    va_list arg;
    va_start(arg, nr_arg);
    pl_char_t **pc;
    pc = pl_slicev(str, nr_arg, arg);
    va_end(arg);
    return pc;
}

pl_char_t **pl_slicev(pl_char_t *str, \
	pl_int_t nr_arg, va_list arg)
{
    pl_char_t *p, *q, *buffer = calloc(1, nr_arg);
    if( buffer==NULL ) return NULL;
    pl_int_t val, len = strlen(str);
    pl_int_t cnt = 1, i, change = 0;
    memset(buffer, 0, nr_arg);
    p = buffer;
    while( (val = va_arg(arg, int))!=0 ) {
	*p++ = val;
    }
    for(q = str; q<str+len; q++) {
	for(p = buffer; p<buffer+nr_arg; p++) {
	    if( *q==*p ) {
		*q = 0;
		if( q==str ) {
		    change = 1;
		}
		if( !change ) {
		    cnt++;
		    change = 1;
		}
		break;
	    }
	}
	if( p>=buffer+nr_arg ) {
	    change = 0;
	}
    }
    if( change ) {
	cnt--;
    }
    pl_char_t **part = calloc(cnt+1, \
		    sizeof(pl_char_t *));
    if( part==NULL ) {
        free(buffer);
	return NULL;
    }
    if( *str==0 ) {
	i = 0;
    } else {
	i = 1;
    }
    for(q = str; q<str+len; q++) {
	if( *q==0 ) {
	    for(; *q==0 && q<str+len; q++)
		;
	    if( q>=str+len ) {
		break;
	    }
	    part[i++] = q;
	}
    }
    if( i!=cnt ) {
        free(buffer);
	return NULL;
    }
    if( *str!=0 ) {
	part[0] = str;
    }
    free(buffer);
    return part;
}

void pl_end_slice(pl_char_t **ptr)
{
    free(ptr);
}

