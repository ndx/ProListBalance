
/*
 * Copyright (C) Niklaus F.Schen.
 */

#define __PL_RULE
#include"pl_access.h"
#include"pl_conf.h"
#include"pl_str.h"
#include"pl_log.h"
#include<string.h>
#include<unistd.h>
#include<stdio.h>
#include<errno.h>
#include<ctype.h>


/*local function declarations*/
static void
pl_process_acl_conf(pl_char_t *buf);
static pl_rule_t *
pl_create_rule_node(void);
static void
pl_mount_rule_node(pl_rule_t *pr);
static void
pl_del_rule_node(pl_rule_t *pr);
static void
pl_set_rule_node(pl_rule_t *pr, pl_int_t num, \
    pl_uint_t ip, pl_int_t netbit, pl_int_t rule);
static pl_rule_t *
pl_add(pl_int_t num, pl_char_t *ip, \
       pl_int_t netbit, pl_char_t *rule);
static pl_rule_t *pl_del(pl_int_t num);
static pl_rule_t *
pl_mod(pl_int_t num, pl_char_t *ip, \
       pl_int_t netbit, pl_char_t *rule);
static pl_rule_t *pl_sel(pl_int_t num);
static void 
pl_check_rule(pl_uint_t *ip, pl_int_t *netbit, \
	      pl_int_t *rule, pl_char_t *part[]);

/*static variables*/
pl_access_t gal;
static pl_char_t acl_path[PATH];
static pl_int_t line, rule_no;

void pl_init_access(void)
{
    memset(&gal, 0, sizeof(pl_access_t));
    memset(acl_path, 0, PATH);
    gal.pool = pl_create_pool();
    pl_domain_t *pd = pl_get_current_domain();
    pl_var_t *pv;
    pv = pl_get_conf(pd->domain, "acl_status", VAR);
    if( pv==NULL ) {
	return ;
    }
    if( pv->type!=STR ) {
	fprintf(stderr, "pl_init_access(): type of \
item 'acl_status' in domain '%s' is error.\n", \
	pd->domain); exit(1);
    }
    if( !strcasecmp(pv->data.str, "off") ) {
	return ;
    } else if( !strcasecmp(pv->data.str, "on") ) {
	gal.status = 1;
    } else {
	fprintf(stderr, "pl_init_access(): value of \
item 'acl_status' in domain '%s' is error.\n", \
	pd->domain); exit(1);
    }
    pv = pl_get_conf(pd->domain, "acl_path", VAR);
    if( pv==NULL ) return ;
    if( pv->type!=STR ) {
	fprintf(stderr, "pl_init_access(): type of \
item 'acl_path' in domain '%s' is error.\n", \
	pd->domain); exit(1);
    }
    if( access(pv->data.str, F_OK)<0 ) {
	fprintf(stderr, "pl_init_access(): '%s' no \
such file or directory.\n", pv->data.str);
	exit(1);
    }
    strcpy(acl_path, pv->data.str);
    pl_get_acl_conf(acl_path);
}

void pl_get_acl_conf(const pl_char_t *path)
{
    FILE *fp;
    pl_int_t len;
    pl_char_t buf[BUF];
    line = 0; rule_no = 0;
    fp = fopen(path, "r");
    if( fp==NULL ) {
	fprintf(stderr, \
	"pl_get_acl_conf(): fopen error. %s.\n", \
	strerror(errno));
    }
lp: memset(buf, 0, BUF);
    fgets(buf, BUF, fp);
    line++;
    len = strlen(buf);
    if( len==1 ) goto lp;
    if( len && buf[len-1]=='\n' ) {
	buf[len-1] = 0;
    }
    while( !feof(fp) ) {
	pl_process_acl_conf(buf);
	goto lp;
    }
    fclose(fp);
}

static void pl_process_acl_conf(pl_char_t *buf)
{
    pl_char_t **part;
    part = pl_slice(buf, 2, ' ', '/', (char *)0);
    if( part==NULL ) {
	fprintf(stderr, \
	"pl_process_acl_conf(): pl_slice error.\n");
	exit(1);
    }
    if( part[0][0]=='#' ) {
	pl_end_slice(part);
	return ;
    }
    if( part[3]!=NULL && strcmp(part[3], "#") ) {
	fprintf(stderr, \
	"pl_process_acl_conf(): line%d: format error.\n", \
	line); exit(1);
    }
    pl_uint_t ip;
    pl_int_t netbit, rule;
    pl_check_rule(&ip, &netbit, &rule, part);
    pl_rule_t *pr = pl_create_rule_node();
    pl_mount_rule_node(pr);
    pl_set_rule_node(pr, rule_no++, ip, netbit, rule);
    pl_end_slice(part);
}

static void pl_check_rule(pl_uint_t *ip, pl_int_t *netbit, \
			pl_int_t *rule, pl_char_t *part[])
{
    *ip = pl_ip_atoi(part[0]);
    if( *ip==IPERR ) {
	fprintf(stderr, \
	"pl_check_rule(): line%d: ip error.\n", line);
	exit(1);
    }
    *netbit = atoi(part[1]);
    if( *netbit<0 || *netbit>32 ) {
	fprintf(stderr, \
	"pl_check_rule(): line:%d netbit error.\n", line);
	exit(1);
    }
    if( !strcasecmp(part[2], "deny") ) {
	*rule = DENY;
    } else if( !strcasecmp(part[2], "allow") ) {
	*rule = ALLOW;
    } else {
	fprintf(stderr, \
	"pl_check_rule(): line:%d rule error.\n", line);
	exit(1);
    }
}

pl_uint_t pl_ip_atoi(pl_char_t *ip)
{
    pl_int_t sum = 0;
    pl_uint_t ip_int = 0, cnt = 3;
    pl_char_t *scan, tmp[4], *p;
    memset(tmp, 0, 4);
    p = tmp;
    for(scan = ip; *scan!=0; scan++) {
	if( *scan=='.' ) {
	    sum = atoi(tmp);
	    if( sum<0 || sum>255 ) {
		return IPERR;
	    }
	    ip_int |= (sum<<(cnt--*8));
	    memset(tmp, 0, 4);
	    p = tmp;
	    continue;
	}
	if( !isdigit(*scan) ) {
	    return IPERR;
	}
	*p++ = *scan;
    }
    sum = atoi(tmp);
    if( sum<0 || sum>255 )
	return IPERR;
    ip_int |= sum;
    if( cnt!=0 ) {
	return IPERR;
    }
    return ip_int;
}

static pl_rule_t *pl_create_rule_node(void)
{
    pl_rule_t *pr;
    pr = pl_alloc(gal.pool, sizeof(pl_rule_t));
    if( pr==NULL ) {
	fprintf(stderr, "pl_create_rule_node(): \
allocate pl_rule_t error.\n"); exit(1);
    }
    return pr;
}

static void pl_mount_rule_node(pl_rule_t *pr)
{
    if( gal.pr==NULL ) {
	gal.pr = gal.pr_tail = pr;
    } else {
	gal.pr_tail->next = pr;
	pr->prev = gal.pr_tail;
	gal.pr_tail = pr;
    }
}

static void pl_del_rule_node(pl_rule_t *pr)
{
    if( pr==gal.pr ) {
	if( pr==gal.pr_tail ) {
	    gal.pr = gal.pr_tail = NULL;
	} else {
	    gal.pr = pr->next;
	    gal.pr->prev = NULL;
	}
    } else {
	if( pr==gal.pr_tail ) {
	    gal.pr_tail = pr->prev;
	    gal.pr_tail->next = NULL;
	} else {
	    pr->next->prev = pr->prev;
	    pr->prev->next = pr->next;
	}
    }
    if( pl_free(pr)<0 ) {
	fprintf(stderr, \
	"pl_del_rule_node(): free pl_rule_t error.\n");
	exit(1);
    }
}

static void pl_set_rule_node(pl_rule_t *pr, \
		pl_int_t num, pl_uint_t ip, \
		pl_int_t netbit, pl_int_t rule)
{
    pl_uint_t mask = 0;
    pl_int_t i, len = 32 - netbit;
    for(i = 0; i<len; i++) {
	mask |= (1<<i);
    }
    pr->num = num;
    pr->ip = ip;
    pr->rule = rule;
    pr->nr_ip = mask;
}

pl_rule_t *pl_ctl_acl_rule(pl_int_t num, \
	pl_char_t *ip, pl_int_t netbit, \
	pl_char_t *rule, pl_int_t type)
{
    if( num>=rule_no ) {
	return NULL;
    }
    switch( type ) {
	case ADDACL:
	    return (pl_add(num, ip, netbit, rule));
	case DELACL:
	    return (pl_del(num));
	case MODACL:
	    return (pl_mod(num, ip, netbit, rule));
	case SELACL:
	    return (pl_sel(num));
	default:
	    fprintf(stderr, \
	    "pl_ctl_acl_rule(): no such type.\n");
	    exit(1);
    }
    return NULL;
}

static pl_rule_t *pl_add(pl_int_t num, \
			pl_char_t *ip, \
			pl_int_t netbit, \
			pl_char_t *rule)
{
    if( num<-1 || num>=rule_no ) {
	return NULL;
    }
    pl_rule_t *pr;
    pl_uint_t ip_int;
    pl_int_t rule_int;
    ip_int = pl_ip_atoi(ip);
    if( ip_int==IPERR ) {
	return NULL;
    }
    if( !strcasecmp(rule, "deny") ) {
	rule_int = DENY;
    } else if( !strcasecmp(rule, "allow") ) {
	rule_int = ALLOW;
    } else {
	return NULL;
    }
    pr = pl_create_rule_node();
    if( num==-1 ) {
	pl_mount_rule_node(pr);
	pl_set_rule_node(pr, rule_no++, \
		ip_int, netbit, rule_int);
	return pr;
    }
    rule_no++;
    pl_set_rule_node(pr, num, ip_int, \
		    netbit, rule_int);
    pl_rule_t *scan;
    pl_int_t mark = 0;
    for(scan = gal.pr; scan!=NULL; scan = scan->next) {
	if( mark ) {
	    scan->num++;
	    continue;
	}
	if( scan->num==num ) {
	    if( scan->num!=0 ) {
		scan->prev->next = pr;
	    }
	    pr->prev = scan->prev;
	    scan->prev = pr;
	    pr->next = scan;
	    scan = pr;
	    if( !pr->num ) {
		gal.pr = pr;
	    }
	    mark = 1;
	}
    }
    return pr;
}


static pl_rule_t *pl_del(pl_int_t num)
{
    if( num<0 || num>=rule_no )
	return NULL;
    pl_rule_t *pr, *save = NULL, *rm;
    pl_int_t mark = 0;
    for(pr = gal.pr; pr!=NULL; ) {
	if( mark ) {
	    pr->num--;
	    pr = pr->next;
	    continue;
	}
	if( pr->num==num ) {
	    rm = pr;
	    if( pr==gal.pr ) {
		if( pr==gal.pr_tail ) {
		    pl_del_rule_node(rm);
		    rule_no--;
		    return ((pl_rule_t *)(&gal));
		} else {
		    pr = pr->next;
		    save = pr;
		    pl_del_rule_node(rm);
		}
	    } else if( pr==gal.pr_tail ) {
		pr = pr->prev;
		save = pr;
		pl_del_rule_node(rm);
		rule_no--;
		return save;
	    } else {
		pr = pr->next;
		save = pr;
		pl_del_rule_node(rm);
	    }
	    mark = 1;
	    rule_no--;
	    continue;
	}
	pr = pr->next;
    }
    return save;
}

static pl_rule_t *pl_mod(pl_int_t num, \
			pl_char_t *ip, \
			pl_int_t netbit, \
			pl_char_t *rule)
{
    if( num<0 || num>=rule_no )
	return NULL;
    pl_rule_t *pr;
    pl_uint_t ip_int;
    pl_int_t rule_int;
    ip_int = pl_ip_atoi(ip);
    if( ip_int==IPERR ) {
	return NULL;
    }
    if( !strcasecmp(rule, "deny") ) {
	rule_int = DENY;
    } else if( !strcasecmp(rule, "allow") ) {
	rule_int = ALLOW;
    } else {
	return NULL;
    }
    for(pr = gal.pr; pr!=NULL; pr = pr->next) {
	if( pr->num==num ) {
	    pl_set_rule_node(pr, num, ip_int, \
			    netbit, rule_int);
	    return pr;
	}
    }
    return NULL;
}

static pl_rule_t *pl_sel(pl_int_t num)
{
    pl_rule_t *pr;
    for(pr = gal.pr; pr!=NULL; pr = pr->next) {
	if( pr->num==num ) {
	    return pr;
	}
    }
    return NULL;
}

pl_int_t pl_get_acl_status(void)
{
    return gal.status;
}

pl_int_t pl_test_acl(pl_char_t *ip)
{
    pl_uint_t remote_ip;
    pl_int_t i;
    remote_ip = pl_ip_atoi(ip);
    if( remote_ip==IPERR ) {
	pl_log(ERROR, "pl_test_acl(): remote ip error.");
    }
    pl_rule_t *pr;
    for(pr = gal.pr; pr!=NULL; pr = pr->next) {
	for(i = 0; i<=pr->nr_ip; i++) {
	    if( pr->ip+i==remote_ip ) {
		if( pr->rule==DENY ) {
		    return -1;
		} else {
		    return 0;
		}	
	    }
	}
    }
    return -1;
}

pl_int_t pl_get_nr_acl(void)
{
    return rule_no;
}

pl_rule_t *pl_get_acllist(void)
{
    return gal.pr;
}

void pl_change_acl_status(pl_int_t status)
{
    gal.status = status;
}

void pl_clean_all_acl(void)
{
    pl_rule_t *pr, *rm;
    pr = gal.pr;
    while( pr!=NULL ) {
	rm = pr;
	pr = pr->next;
	if( pl_free(rm)<0 ) {
	    pl_log(EMERGE, \
	    "pl_clean_all_acl(): free pl_rule_t error.");
	}
	rule_no--;
    }
    gal.pr = gal.pr_tail = NULL;
}

/*void pl_print_acl(void)
{
	pl_rule_t *pr;
	for(pr = gal.pr; pr!=NULL; pr = pr->next) {
		printf("num:%d ip:%x nr_ip:%d rule:%x\n", \
			pr->num, pr->ip, pr->nr_ip, pr->rule);
	}
}*/

