
/*
 * Copyright (C) Niklaus F.Schen.
 */

#ifndef __PL_LOCK
#define __PL_LOCK

#include"pl_types.h"

void pl_create_lock(void);
void pl_remove_lock(void);
pl_int_t pl_add_lock(void);
void pl_unlock(void);
#endif

