
/*
 * Copyright (C) Niklaus F.Schen.
 */

/*
functions:
	pl_request_recv() pl_request_send()
	pl_close_socket()
	pl_console_recv() pl_console_send()
	p;_master_ipc_send() pl_master_ipc_recv()
	pl_worker_ipc_recv() pl_worker_ipc_send()
	pl_send_package_num()
*/

#ifndef __PL_IO
#define __PL_IO
#include"pl_types.h"
#include"pl_socket.h"
#include"pl_console.h"

#define BUFFER 1024
#define BUFLIMIT 8
#define POSITIVE 1

typedef void (*pl_cmd_process)\
		(pl_socket_t *ps, \
	pl_console_package_t *pcp);


void pl_request_recv(pl_socket_t *ps, \
			pl_int_t flg);
void pl_request_send(pl_socket_t *ps, \
			pl_int_t flg);
void pl_close_socket(pl_socket_t *ps, pl_int_t flg);
void pl_console_recv(pl_socket_t *ps, const pl_char_t *func);
void pl_console_send(pl_socket_t *ps, const pl_char_t *func);
void pl_master_ipc_send(pl_socket_t *ps, const pl_char_t *func);
void pl_master_ipc_recv(pl_socket_t *ps, const pl_char_t *func);
void pl_worker_ipc_recv(pl_socket_t *ps, const pl_char_t *func);
void pl_worker_ipc_send(pl_socket_t *ps, const pl_char_t *func);
void pl_send_package_num(pl_socket_t *ps, pl_int_t num);
#endif

