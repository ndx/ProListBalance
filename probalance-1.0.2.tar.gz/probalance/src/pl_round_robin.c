
/*
 * Copyright (C) Niklaus F.Schen.
 */

#include"pl_types.h"
#include"pl_round_robin.h"
#include"pl_statistics.h"

pl_server_t *round_robin(pl_server_t *srvlist, \
			pl_algorithm_data_t *data)
{
    if( srvlist==NULL ) {
	return NULL;
    }
    pl_server_t *ps, *rv;
    pl_int_t greater = 0, alldown = 1;
    pl_int_t weight, down;
    while( 1 ) {
	for(ps = srvlist; ps!=NULL; ps = ps->next) {
	    pl_get_stat_value(&(ps->info), \
		VDOWN, &down, sizeof(down));
	    if( down ) {
		continue;
	    } else {
		alldown = 0;
	    }
	    pl_get_stat_value(&(ps->info), \
		VCWEIGHT, &weight, sizeof(weight));
	    if( weight>greater ) {
		rv = ps;
		greater = weight;
	    }
	}
	if( alldown ) {
	    return NULL;
	}
	if( !greater ) {
	    for(ps = srvlist; ps!=NULL; ps = ps->next) {
		pl_get_stat_value(&(ps->info), \
		    VWEIGHT, &weight, sizeof(weight));
		pl_stat_ctl(&(ps->info), CWEIGHT, VALUE, weight);
	    }
	} else {
	    pl_stat_ctl(&(rv->info), CWEIGHT, DEC, 0);
	    return rv;
	}
    }
    return NULL;
}

