#include"pl_server.h"
#include"pl_statistics.h"
pl_server_t *leastconnection(pl_server_t *srvlist, \
			   pl_algorithm_data_t *data)
{
    pl_server_t *srv = NULL, *scan;
    pl_ullong_t connections, min = ~0;
    pl_int_t down, weight;
    for(scan = srvlist; scan!=NULL; \
		    scan = scan->next )
    {
	pl_get_stat_value(&(scan->info), \
	VDOWN, &down, sizeof(down));
	if( down ) continue;
	pl_get_stat_value(&(scan->info), \
	VWEIGHT, &weight, sizeof(weight));
	pl_get_stat_value(&(scan->info), \
	VCURRENT, &connections, sizeof(connections));
	connections += (connections/(1+weight));
	if( connections<min ) {
	    srv = scan;
	    min = connections;
	}
    }
    return srv;
}

