
/*
 * Copyright (C) Niklaus F.Schen.
 */

#include<stdio.h>
#include<stdlib.h>
#include"pl_log.h"
#include"pl_conf.h"
#include"pl_types.h"
#include"pl_daemon.h"
#include"pl_syslimit.h"
#include"pl_fork.h"
#include"pl_event.h"
#include"pl_lock.h"
#include"pl_access.h"
#include"pl_global.h"
#include"pl_dynamic_lib.h"
/*local function declarations*/
static void pl_init(void);
static void 
pl_check_parameter(pl_int_t argc, \
		pl_char_t *argv[]);

int main(int argc, char *argv[])
{
    pl_check_parameter(argc,argv);
    pl_init();
    pl_fork(argv);
    while( pl_event(argv)==WORKER )
	{}
    exit(0);
}

static void pl_init(void)
{
    nr_fds = 0;
    pl_load_conf("conf/probalance.conf");
    pl_init_access();
    pl_init_daemon();
    pl_init_log();
    pl_init_socket();
    pl_init_server();
    pl_init_sysresource();
    pl_init_dynamic_lib();
    pl_create_lock();
}

static void 
pl_check_parameter(pl_int_t argc, pl_char_t *argv[])
{
    if( argc>1 ) {
	if( argc>2 ) {
err:	    fprintf(stderr,"Parameter error.\n");
	    exit(1);
	}
	if( !strcmp(argv[1], "--version") ) {
	    printf("ProList Load Balancer. \
Version 1.0.\n"); exit(0);
	} else {
	    goto err;
	}
    }
}

