
/*
 * Copyright (C) Niklaus F.Schen.
 */

#ifndef __PL_IP_HASH
#define __PL_IP_HASH

#include"pl_server.h"
#include"pl_types.h"

#define TBLLEN 256
#define PREFIX 4

typedef struct pl_hash_table_s {
	pl_server_t *srv;
	pl_int_t key;
}pl_hash_table_t;

pl_server_t *ip_hash(pl_server_t *srvlist, \
	pl_algorithm_data_t *data);
void pl_clean_hash_table(void);

#endif

