
/*
 * Copyright (C) Niklaus F.Schen.
 */

#include"pl_log.h"
#include<unistd.h>
#include"pl_conf.h"
#include<stdarg.h>
#include<signal.h>
#include<string.h>
#include<errno.h>
#include<sys/types.h>
#include<stdio.h>
#include<time.h>
#include<fcntl.h>
#include<sys/stat.h>
/*local function declarations*/
static void pl_logv(pl_int_t prio, \
	pl_char_t *fmt, va_list arg);
static pl_int_t pl_get_log_status(void);
#define STATUS pl_get_log_status()
/*static variables*/
static pl_int_t debugfd;
static pl_int_t errorfd;
static pl_int_t emergefd;

void pl_init_log(void)
{
    pl_domain_t *pd = pl_get_current_domain();
    pl_var_t *pv;
    pl_domain_t *scan = pd;
    for(; scan!=NULL; scan = scan->next) {
	pv = pl_get_conf(scan->domain, "log_status", VAR);
	if( pv==NULL ) {
	    fprintf(stderr, \
		"No variable log_status in domain %s.\n", \
		scan->domain); exit(1);
	}
	if( pv->type!=STR ) {
	    fprintf(stderr, "Variable 'log_status' type \
is not string in domain %s.\n", scan->domain); exit(1);
	}
	if( strcasecmp(pv->data.str, "on") && \
	    strcasecmp(pv->data.str, "off") )
	{
	    fprintf(stderr, "Variable 'log_status' value \
is neither 'on' nor 'off' in domain %s.\n", scan->domain);
	    exit(1);
	}
    }
    if( access("log", F_OK)<0 ) {
	if( mkdir("log", S_IRUSR | S_IWUSR | \
		S_IXUSR | S_IRGRP | S_IROTH)<0 )
	{
	    fprintf(stderr, \
		"pl_init_log(): cannot mkdir log.%s\n", \
		strerror(errno)); exit(1);
	}
    }
    pl_int_t creatflg = O_WRONLY|O_APPEND|O_CREAT;
    pl_int_t openflg = O_WRONLY|O_APPEND;
    pl_int_t umask = S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH;
    if( access("log/debug.conf", F_OK)<0 ) {
	debugfd = open("log/debug.log", creatflg, umask);
    } else {
	debugfd = open("log/debug.log", openflg);
    }
    if( debugfd<0 ) {
	fprintf(stderr, \
	"pl_init_log(): open debug.conf error. %s\n", \
	strerror(errno)); exit(1);
    }

    if( access("log/error.log", F_OK)<0 ) {
	errorfd = open("log/error.log", creatflg, umask);
    } else {
	errorfd = open("log/error.log", openflg);
    }
    if( errorfd<0 ) {
	fprintf(stderr, \
	"pl_init_log(): open error.conf error. %s\n", \
	strerror(errno)); exit(1);
    }

    if( access("log/emerge.log", F_OK)<0 ) {
	emergefd = open("log/emerge.log", creatflg, umask);
    } else {
	emergefd = open("log/emerge.log", openflg);
    }
    if( emergefd<0 ) {
	fprintf(stderr, \
	"pl_init_log(): open emerge.conf error. %s\n", \
	strerror(errno)); exit(1);
    }
}

void pl_log(pl_int_t prio, pl_char_t *fmt, ...)
{
    pl_int_t error = errno;
    if( prio>ERROR && !STATUS ) {
	return;
    }
    va_list arg;
    va_start(arg, fmt);
    pl_logv(prio, fmt, arg);
    va_end(arg);
    errno = error;
    if( prio==EMERGE ) {
	raise(SIGINT);
    } else if( prio==ERROR ) {
	raise(SIGKILL);
    }
}

static void pl_logv(pl_int_t prio, \
	pl_char_t *fmt, va_list arg)
{
    pl_int_t fd;
    switch( prio ) {
	case DEBUG:
	    fd = debugfd;
	    break;
	case ERROR:
	    fd = errorfd;
	    break;
	case EMERGE:
	    fd = emergefd;
	    break;
	default:
	    write(emergefd, \
	    "no such error priority.\n", 24);
	    return;
    }
    pl_char_t buf[LOGBUFLEN];
    memset(buf, 0, LOGBUFLEN);
    pl_time_t tm;
    time(&tm);
    strcpy(buf, ctime(&tm));
    if( buf[strlen(buf)-1]=='\n' ) {
	buf[strlen(buf)-1] = ' ';
    }
    char *p = buf + strlen(buf);
    while( *fmt!=0 ) {
	if( *fmt!='%' ) {
	    *p++ = *fmt++;
	    continue;
	}
	if( *(fmt+1)==0 ) {
	    write(emergefd, \
	    "log content format error.\n", 26);
	    return ;
	}
	if( *(fmt+1)=='%' ) {
	    *p++ = *(fmt+1);
	    fmt += 2;
	    continue;
	}
	switch( *++fmt ) {
	    case 's':
		    {
			pl_char_t *str;
			str = va_arg(arg, char *);
			strcat(p, str);
			p += strlen(p);
			break;
		    }
	    case 'd':
		    {
			pl_char_t str_num[LOGBUFLEN];
			memset(str_num, 0, LOGBUFLEN);
			pl_int_t integer;
			integer = va_arg(arg, int);
			sprintf(str_num, "%d", integer);
			strcat(p, str_num);
			p += strlen(str_num);
			break;
		    }
	    case 'c':
		    {
			pl_int_t ch;
			ch = va_arg(arg, int);
			*p++ = (pl_char_t)ch;
			break;
		    }
	    default:
		    break;
	}
	fmt++;
    }
    buf[strlen(buf)] = '\n';
    write(fd, buf, strlen(buf));
    if( prio<=ERROR || STATUS ) {
	fprintf(stderr, "%s", buf);
    }
}

static pl_int_t pl_get_log_status(void)
{
    pl_var_t *pv;
    pl_domain_t *pd = pl_get_current_domain();
    pv = pl_get_conf(pd->domain, "log_status", VAR);
    if( pv==NULL ) {
	return 0;
    }
    if( !strcasecmp(pv->data.str, "on") ) {
	return 1;
    } else {
	return 0;
    }
}

