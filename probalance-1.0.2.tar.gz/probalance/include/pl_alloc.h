
/*
 * Copyright (C) Niklaus F.Schen.
 */

/*
Functions:
	pl_create_pool() pl_alloc() pl_free()
	pl_destory_pool()
attention:
	If users want to use pl_alloc() to allocate a 
	memory block, you need to call pl_create_pool()	
	to create a pool at first.
	After calling pl_destory_pool(), don't forget
	to set pointer to equal NULL.
*/

#ifndef __MLIB_ALLOC
#define __MLIB_ALLOC
#include<string.h>
#include<stdlib.h>

#define LIMIT 1024

typedef struct pl_block_s {
	void *blk;
	struct pl_block_s *next;
	struct pl_block_s *prev;
}pl_block_t;

typedef struct pl_list_s {
	unsigned long long size;
	unsigned long long nr_free;
	unsigned long long nr_used;
	pl_block_t *used;
	pl_block_t *free;
}pl_list_t;

typedef struct pl_pool_s {
	pl_list_t list[sizeof(long *)<<3];
}pl_pool_t;

extern pl_pool_t *pl_create_pool(void);
extern void *pl_alloc(pl_pool_t *pool, unsigned long size);
extern int pl_free(void *ptr);
extern void pl_destory_pool(pl_pool_t *pool);
extern void pl_pool_print(pl_pool_t *pool);
#endif

