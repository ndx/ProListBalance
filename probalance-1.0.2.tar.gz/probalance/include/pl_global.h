
/*
 * Copyright (C) Niklaus F.Schen.
 */

#ifndef __PL_GLOBAL
#define __PL_GLOBAL
#include"pl_statistics.h"
#include"pl_types.h"

#ifndef __REAL_VARIABLE
#define EXTERN extern
#else
#define EXTERN
#endif

EXTERN pl_int_t nr_restart;
EXTERN pl_int_t nr_fds;
EXTERN pl_int_t console_existed;
EXTERN pl_statinfo_t clientinfo;
EXTERN pl_char_t galname[256];

#endif

