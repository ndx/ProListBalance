
/*
 * Copyright (C) Niklaus F.Schen.
 */

/*
Functions:
	pl_create_pool() pl_alloc() pl_free()
	pl_destory_pool()
attention:
	If users want to use pl_alloc() to allocate a 
	memory block, you need to call pl_create_pool()	
	to create a pool at first.
	After calling pl_destory_pool(), don't forget
	to set pointer to equal NULL.
*/

#ifndef __PL_ALLOC
#define __PL_ALLOC
#include"pl_types.h"
#include<string.h>
#include<stdlib.h>

#define LIMIT 8192

typedef struct pl_block_s {
	void *blk;
	struct pl_block_s *next;
	struct pl_block_s *prev;
}pl_block_t;

typedef struct pl_list_s {
	pl_int_t size;
	pl_int_t nr_free;
	pl_int_t nr_used;
	pl_block_t *used;
	pl_block_t *free;
	struct pl_list_s *next;
}pl_list_t;

typedef struct pl_pool_s {
	pl_list_t *list;
}pl_pool_t;

pl_pool_t *pl_create_pool(void);
void *pl_alloc(pl_pool_t *pool, pl_int_t size);
pl_int_t pl_free(void *ptr);
void pl_destory_pool(pl_pool_t *pool);
#endif

