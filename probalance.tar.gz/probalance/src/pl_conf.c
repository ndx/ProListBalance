
/*
 * Copyright (C) Niklaus F.Schen.
 */

#include"pl_conf.h"
/*static declarations*/
static pl_int_t pl_check_depth(pl_char_t **part);
static void pl_create_string(pl_var_t *pv, \
	pl_conf_t *pc, pl_char_t *buf);
static void pl_semicolon_default(pl_char_t **part, \
		pl_domain_t *pd, pl_conf_t *pc);
static pl_int_t pl_type_check(pl_char_t *buf);
static pl_domain_t *pl_create_domain(pl_conf_t *pc, \
	pl_char_t *domain, pl_int_t layer, pl_domain_t *old);
static void pl_put_var(pl_domain_t *pd, pl_var_t *pv);
static pl_var_t *pl_create_var(pl_conf_t *pc, \
		const pl_char_t *domain, \
		const pl_char_t *varname, \
		pl_int_t type, pl_int_t layer, \
		pl_int_t depth);
static void pl_check_string(pl_char_t *str);
static void pl_check_digit(pl_char_t *value);
static void pl_check_varname(pl_char_t *name);
static void pl_equal_check(pl_char_t **part);
static void pl_right_brace(FILE *fp, \
	pl_char_t *buf, pl_domain_t *pd);
static void pl_left_brace(FILE *fp, \
	pl_char_t *buf, pl_domain_t *pd, \
	pl_conf_t *pc);
static void pl_semicolon(pl_char_t *buf, \
	pl_domain_t *pd, pl_conf_t *pc);
static pl_int_t pl_process_line(FILE *fp, \
	pl_char_t *buf, pl_domain_t *pd, \
	pl_conf_t *pc);
static void pl_read_from_conf(FILE *fp, \
	pl_domain_t *pd, pl_conf_t *pc);

/*static variables*/
static pl_int_t nr_line;
static pl_int_t layer;
static pl_var_cache_t cachetbl[CACHELEN];
static pl_domain_t *gpd;
static pl_conf_t *gpc;

void pl_load_conf(const pl_char_t *path)
{
    gpc = calloc(1, sizeof(pl_conf_t));
    if( gpc==NULL ) {
	fprintf(stderr, "pl_load_conf(): \
allocate pl_conf_t error.\n"); exit(1);
    }
    nr_line = 0; layer = 0;
    memset(cachetbl, 0, \
	sizeof(pl_var_cache_t)*CACHELEN);
    FILE *fp;
    fp = fopen(path, "r");
    if( fp==NULL ) {
	fprintf(stderr, "pl_load_conf(): \
open conf/probalance.conf error.%s\n", \
	strerror(errno)); exit(1);
    }
    gpc->pool = pl_create_pool();
    if( gpc->pool==NULL ) {
	fprintf(stderr, \
	"pl_load_conf(): create pool error.\n");
	exit(1);
    }
    gpc->pd = pl_create_domain(gpc, "main", layer, NULL);
    gpd = gpc->pd;
    pl_read_from_conf(fp, gpc->pd, gpc);
    fclose(fp);
}

static void pl_read_from_conf(FILE *fp, \
	pl_domain_t *pd, pl_conf_t *pc)
{
    pl_char_t buf[LINELEN];
    pl_int_t len;
    memset(buf, 0, LINELEN);
    fgets(buf, LINELEN, fp);
    nr_line++;
    while( !feof(fp) ) {
	len = strlen(buf);
	if( len && buf[len-1]=='\n' ) {
	    buf[len-1] = 0;
	}
	if( pl_process_line(fp, buf, pd, pc)<0 ) {
	    return ;
	}
	memset(buf, 0, LINELEN);
	fgets(buf, LINELEN, fp);
	nr_line++;
    }
}

static pl_int_t pl_process_line(FILE *fp, \
	pl_char_t *buf, pl_domain_t *pd, \
	pl_conf_t *pc)
{
    pl_char_t *p, *record;
    for(p = buf; *p==' ' || *p=='\t'; p++)
	;
    if( *p==0 ) {
	return 0;
    }
    if( *p=='#' ) {
	return 0;
    }
    for(; *p!=';' && *p!=0 && \
	*p!='{' && *p!='}'; p++)
	;
    if( *p!=0 ) {
	record = p;
	for(p++; *p!=0; p++) {
	    if( *p!=' ' && *p!='\t' ) {
		fprintf(stderr, \
		"Line:%d syntax error. Line \
should be terminated by ';', '{' or '}'.\n", \
		nr_line); exit(1);
	    }
	}
	p = record;
    }
    switch( *p ) {
	case ';':
	    pl_semicolon(buf, pd, pc);
	    break;
	case '{':
	    pl_left_brace(fp, buf, pd, pc);
	    break;
	case '}':
	    pl_right_brace(fp, buf, pd);
	    return -1;
	default:
	    fprintf(stderr, \
	    "Line:%d the last symbol is error.\n", \
	    nr_line); exit(1);
    }
    return 0;
}

/*add part*/
static void pl_semicolon(pl_char_t *buf, \
	pl_domain_t *pd, pl_conf_t *pc)
{
    pl_char_t **part;
    part = pl_slice(buf, 3, ' ', ';', '\t', (char *)0);
    if( part==NULL ) {
	fprintf(stderr, \
	"pl_semicolon(): pl_slice error.\n");
	exit(1);
    }
    pl_equal_check(part);
    pl_semicolon_default(part, pd, pc);
    pl_end_slice(part);
}

static void pl_semicolon_default(pl_char_t **part, \
	pl_domain_t *pd, pl_conf_t *pc)
{
    pl_var_t *pv;
    pl_char_t *varname, *rval;
    pl_int_t depth;
    if( (depth = pl_check_depth(part))!=LIMITED ) {
	varname = part[1];
	rval = part[3];
    } else {
	varname = part[0];
	rval = part[2];
    }
    pl_check_varname(varname);
    pv = pl_get_conf(pd->domain, varname, VAR);
    pl_int_t type = pl_type_check(rval);
    if( pv!=NULL ) {
	if( depth==UNLIMITED ) {
	    pv->unlimited = 1;
	} else if( depth==LIMITED ) {
	    if( !pv->unlimited ) {
		(pv->depth)--;
	    }
	} else {
	    pv->unlimited = 0;
	    pv->depth = depth;
	}
	if( pv->type==STR ) {
	    if( pl_free(pv->data.str)<0 ) {
		fprintf(stderr, \
		"pl_semicolon_default(): \
no memory can be freed.\n"); exit(1);
	    }
lp:	    if( type==INT ) {
		pv->data.value = atoi(rval);
		pv->type = INT;
	    } else if( type==CHAR ) {
		pv->data.ch = rval[1];
		pv->type = CHAR;
	    } else {
		pl_create_string(pv, pc, rval);
		pv->type = STR;
	    }
	} else {
	    goto lp;
	}
    } else {
	pv = pl_create_var(pc, pd->domain, \
		varname, type, pd->layer, depth);
	switch( type ) {
	    case INT:
		pv->data.value = atoi(rval);
		break;
	    case CHAR:
		pv->data.ch = rval[1];
		break;
	    case STR:
		pl_create_string(pv, pc, rval);
	}
	pl_put_var(pd, pv);
    }
}

static pl_int_t pl_check_depth(pl_char_t **part)
{
    if( part[0][0]=='$' ) {
	pl_char_t *scan;
	if( !strcmp((part[0]+1), "-") ) {
	    return -1;
	}
	for(scan = &part[0][1]; *scan!=0; scan++) {
	    if( !isdigit(*scan) ) {
		fprintf(stderr, \
		"Line:%d prefix layer error.\n", \
		nr_line); exit(1);
	    }
	}
	pl_int_t depth = atoi(&part[0][1]);
	if( depth>65536 ) {
	    fprintf(stderr, "Line:%d prefix layer \
max limitation is 65535 or set '-' to be unlimited.\n", \
	    nr_line); exit(1);
	}
	return depth;
    } else {
	if( part[3]!=NULL ) {
	    fprintf(stderr, \
	    "Line:%d expression error.\n", nr_line);
	    exit(1);
	}
    }
    return -255;
}

static void pl_create_string(pl_var_t *pv, \
	pl_conf_t *pc, pl_char_t *buf)
{
    pv->data.str = pl_alloc(pc->pool, strlen(buf)-2);
    if( pv->data.str==NULL ) {
	fprintf(stderr, "pl_create_string(): \
allocate string buffer error.\n"); exit(1); 
    }
    memcpy(pv->data.str, buf+1, strlen(buf)-2);
}

static pl_int_t pl_type_check(pl_char_t *buf)
{
    switch( *buf ) {
	case '\'':
	    if( strlen(buf)!=3 || buf[2]!='\'' ) {
		fprintf(stderr, "Line:%d char \
variable definition error.\n", nr_line); exit(1);
	    }
	    return CHAR;
	    break;
	case '"':
	    pl_check_string(buf);
	    return STR;
	    break;
	default:
	    if( *buf=='-' ) {
		pl_check_digit(buf+1);
	    } else {
		pl_check_digit(buf);
	    }
    }
    return INT;
}

static void pl_equal_check(pl_char_t **part)
{
    if( part[0]==NULL || part[1]==NULL ) {
	goto err;
    }
    pl_char_t *optr, *rval;
    if( part[0][0]=='$' ) {
	optr = part[2];
	rval = part[3];
    } else {
	optr = part[1];
	rval = part[2];
    }
    if( strcmp(optr, "=") || rval==NULL ) {
err:	fprintf(stderr, \
	"Line:%d expression error.\n", \
	nr_line); exit(1);
    }
}

static void pl_left_brace(FILE *fp, \
	pl_char_t *buf, pl_domain_t *pd, \
	pl_conf_t *pc)
{
    pl_char_t **part;
    if( &buf[strlen(buf)-2]<=buf || \
	buf[strlen(buf)-2]!=' ' )
    {
	fprintf(stderr, "Line:%d Zone name and \
'{' should be in the same line or lost a space \
character.\n", nr_line); exit(1);
    }
    part = pl_slice(buf, 2, ' ', '\t', (char *)0);
    if( part==NULL ) {
	fprintf(stderr, \
	"pl_left_brace(): pl_slice error.\n");
	exit(1);
    }
    if( part[1][0]!='{' ) {
	fprintf(stderr, \
	"Line:%d format of zone definition error.\n", \
	nr_line); exit(1);
    }
    layer++;
    pl_domain_t *newd;
    newd = pl_create_domain(pc, part[0], layer, pd);
    pl_read_from_conf(fp, newd, pc);
    pl_end_slice(part);
}

static void pl_right_brace(FILE *fp, \
	pl_char_t *buf, pl_domain_t *pd)
{
    pl_char_t *p;
    for(p = buf; *p==' ' || *p=='\t'; p++)
	;
    if( *p!='}' ) {
	fprintf(stderr, \
	"Line:%d '{' should be in a new line.\n", \
	nr_line); exit(1);
    }
    layer--;
}

static void pl_check_varname(pl_char_t *name)
{
    pl_char_t *scan;
    if( !isalpha(*name) ) {
	goto err;
    }
    for(scan = name+1; *scan!=0; scan++) {
	if( !isdigit(*scan) && \
	    !isalpha(*scan) && \
	    *scan!='_' )
	{
err:	    fprintf(stderr, \
	    "Line:%d variable [%s] definition error.\n", \
	    nr_line, name); exit(1);
	}
    }
}

static void pl_check_digit(pl_char_t *value)
{
    pl_char_t *scan;
    for(scan = value; *scan!=0; scan++) {
	if( !isdigit(*scan) ) {
	    fprintf(stderr, \
	    "Line:%d integer definition error.\n", \
	    nr_line); exit(1);
	}
    }
}

static pl_var_t *pl_create_var(pl_conf_t *pc, \
		const pl_char_t *domain, \
		const pl_char_t *varname, \
		pl_int_t type, pl_int_t layer, \
		pl_int_t depth)
{
    pl_var_t *pv;
    pv = pl_alloc(pc->pool, sizeof(pl_var_t));
    if( pv==NULL ) {
	fprintf(stderr, \
	"pl_create_var(): allocate memory error.\n");
	exit(1);
    }
    strcpy(pv->domain, domain);
    strcpy(pv->varname, varname);
    pv->type = type;
    pv->layer = layer;
    if( depth==UNLIMITED ) {
	pv->unlimited = 1;
    } else if( depth==LIMITED ) {
	pv->unlimited = 0;
	pv->depth = 0;
    } else {
	pv->unlimited = 0;
	pv->depth = depth;
    }
    return pv;
}

static void pl_check_string(pl_char_t *str)
{
    pl_int_t len = strlen(str);
    if( len<3 || *str!='"' || str[len-1]!='"' ) {
	fprintf(stderr, \
	"Line:%d string definition error.\n", \
	nr_line); exit(1);
    }
}

static void pl_put_var(pl_domain_t *pd, \
			    pl_var_t *pv)
{
    if( pd->pv==NULL ) {
	pd->pv = pd->pv_tail = pv;
    } else {
	pd->pv_tail->next = pv;
	pd->pv_tail = pv;
    }
}

static pl_domain_t *pl_create_domain(pl_conf_t *pc, \
		pl_char_t *domain, pl_int_t layer, \
		pl_domain_t *old)
{
    pl_domain_t *pd = pl_get_conf(domain, NULL, DOM);
    if( pd!=NULL ) {
	fprintf(stderr, \
	"Line:%d domain '%s' repeat defined.\n", \
	nr_line, domain); exit(1);
    }
    pd = pl_alloc(pc->pool, sizeof(pl_domain_t));
    if( pd==NULL ) {
	fprintf(stderr, \
	"pl_create_domain(): allocate pl_domain_t error.\n");
	exit(1);
    }
    if( old!=NULL ) {
	memcpy(pd, old, sizeof(pl_domain_t));
	memset(pd->domain, 0, DOMAINNAME);
	pd->pv = pd->pv_tail = NULL;
	old->next = pd;
	pl_var_t *pv, *new;
	for(pv = old->pv; pv!=NULL; pv = pv->next) {
	    if( !pv->unlimited && !pv->depth ) {
		continue;
	    }
	    new = pl_alloc(pc->pool, sizeof(pl_var_t));
	    if( new==NULL ) {
		fprintf(stderr, "pl_create_domain(): \
allocate pl_var_t error.\n"); exit(1);
	    }
	    memcpy(new, pv, sizeof(pl_var_t));
	    if( !new->unlimited ) {
		new->depth--;
	    }
	    pl_put_var(pd, new);
	}
    }
    strcpy(pd->domain, domain);
    pd->layer = layer;
    return pd;
}

pl_int_t pl_nr_expression_check(pl_char_t **part, \
				   pl_int_t require)
{
    pl_int_t count = 0;
    while( *part!=NULL ) {
	count++;
	part++;
    }
    return ( count-require );
}

void pl_check_nr_expression(pl_char_t **part, \
				pl_int_t require)
{
    if( pl_nr_expression_check(part, require) ) {
	fprintf(stderr, \
	"Line:%d expression error.\n", nr_line);
	exit(1);
    }
}

void *pl_get_conf(const pl_char_t *domain, \
		    const pl_char_t *var, \
		    pl_int_t flg)
{
    if( domain==NULL ) {
	return NULL;
    }
    if( (flg&DOSW && flg&SWIT) || \
	(flg&VAR && flg&DOM) || \
	(flg&NONE && flg!=NONE) )
    {
	return NULL;
    }
    pl_var_cache_t *save = NULL, *scan;
    pl_uint_t min = ~0;
    for(scan = cachetbl; \
	scan<cachetbl+CACHELEN; \
	scan++)
    {
	if( !scan->actived ) {
	    if( save==NULL || save->actived ) {
		save = scan;
	    }
	    continue;
	} else {
	    if( scan->nr_used<min ) {
		if( save==NULL || save->actived ) {
		    min = scan->nr_used;
		    save = scan;
		}
	    }
	}
	if( !strcmp(domain, scan->pd->domain) ) {
	    if( flg&DOM ) {
		if( ++scan->nr_used>65535 ) {
		    scan->nr_used--;
		}
		if( flg&DOSW ) {
		    gpd = scan->pd;
		}
		return scan->pd;
	    }
	    if( var==NULL ) {
		return NULL;
	    }
	    if( scan->pv==NULL ) {
		save = scan;
		break;
	    }
	    if( !strcmp(var, scan->pv->varname) ) {
		if( ++scan->nr_used>65535 ) {
		    scan->nr_used--;
		}
		if( flg&SWIT ) {
		    gpd = scan->pd;
		}
		return scan->pv;
	    }
	}
    }
    pl_domain_t *pd;
    pl_var_t *pv;
    for(pd = gpc->pd; pd!=NULL; pd = pd->next) {
	if( !strcmp(pd->domain, domain) ) {
	    if( flg&DOSW ) {
		gpd = pd;
	    }
	    if( flg&DOM ) {
		save->pv = NULL;
		save->pd = pd;
		save->actived = 1;
		save->nr_used = 0;
		return pd;
	    }
	    if( var==NULL ) {
		return NULL;
	    }
	    for(pv = pd->pv; pv!=NULL; pv = pv->next) {
		if( !strcmp(pv->varname, var) ) {
		    if( flg&SWIT ) {
			gpd = pd;
		    }
		    save->pv = pv;
		    save->pd = pd;
		    save->actived = 1;
		    save->nr_used = 0;
		    return pv;
		}
	    }
	}
    }
    return NULL;
}

pl_domain_t *pl_get_current_domain(void)
{
    return gpd;
}

/*void pl_print(void)
{
	pl_domain_t *pd;
	pl_var_t *pv;
	pl_var_cache_t *pvc;
	printf("ALL:\n");
	for(pd = gpc->pd; pd!=NULL; pd = pd->next) {
		printf("Domain: %s\n", pd->domain);
		printf("Layer: %d\n", pd->layer);
		for(pv = pd->pv; pv!=NULL; pv = pv->next) {
			printf("\tVarible name: %s\n", pv->varname);
			printf("\t");
			switch( pv->type ) {
				case INT:
					printf("Type: int\n");
					printf("\tValue: %d\n", pv->data.value);
					break;
				case CHAR:
					printf("Type: char\n");
					printf("\tValue: %c\n", pv->data.ch);
					break;
				case STR:
					printf("Type: string\n");
					printf("\tValue: %s\n", pv->data.str);
					break;
				default:
					printf("\tNo such type.\n");
					break;
			}
			printf("\tBelong to domain: %s\n", pv->domain);
			printf("\tVariable layer: %d\n", pv->layer);
			printf("\tLimitation status: %s\n", pv->unlimited?"NO":"YES");
			printf("\tDepth: %d\n\n", pv->depth);
		}
		printf("\n");
	}
	printf("CACHE:\n");
	for(pvc = cachetbl; pvc<cachetbl+CACHELEN; pvc++) {
		printf("pv:%x\npd:%x\nactived:%d\nnr_used:%d\n\n", \
		pvc->pv, pvc->pd, pvc->actived, pvc->nr_used);
	}
}*/

