
/*
 * Copyright (C) Niklaus F.Schen.
 */

#include"pl_conf.h"
#include"pl_socket.h"
#include"pl_fork.h"
#include"pl_log.h"
#include"pl_global.h"
#include"pl_io.h"
#include"pl_event.h"
#include<sys/time.h>
#include<errno.h>
#include<string.h>
#include<time.h>
#include<signal.h>
#include<unistd.h>
#include<fcntl.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/tcp.h>

/*function declarations*/
static void pl_create_listen_socket(pl_domain_t *pd, \
	const pl_char_t *item_ip, \
	const pl_char_t *item_port, \
	pl_int_t type);
static void pl_connection_cache_heartbeat(pl_int_t signo);
/*static variables*/
static pl_queue_t gpq;
static pl_event_cache_t event_cache[CACHESIZE];
static pl_event_cache_t *cache_get, *cache_put;
static pl_int_t nr_cache_available;

void pl_init_socket(void)
{
    memset(&gpq, 0, sizeof(gpq));
    gpq.pool = pl_create_pool();
    if( gpq.pool==NULL ) {
	pl_log(ERROR, \
	"pl_init_socket(): create pool error.");
    }
    pl_domain_t *pd = pl_get_current_domain();
    /*get connection_cache conf*/
    pl_var_t *pv = pl_get_conf(pd->domain, \
		    "connection_cache", VAR);
    if( pv==NULL ) {
	gpq.cache_status = 0;
    } else {
	if( pv->type!=STR ) {
	    pl_log(EMERGE, "pl_init_socket(): type of \
item 'connection_cache' in domain '%s' is error.", \
	    pd->domain);
	}
	if( !strcasecmp(pv->data.str, "on") ) {
	    gpq.cache_status = 1;
	} else if( !strcasecmp(pv->data.str, "off") ) {
	    gpq.cache_status = 0;
	} else {
	    pl_log(EMERGE, "pl_init_socket(): value of \
item 'connection_cache' in domain '%s' is error.", \
	    pd->domain);
	}
    }
    /*create_socket*/
    pl_create_listen_socket(pd, "request_ip", \
			"request_port", LISTEN);
    pl_create_listen_socket(pd, "console_ip", \
			"console_port", CONSOLE);
}

static void pl_create_listen_socket(pl_domain_t *pd, \
			    const pl_char_t *item_ip, \
			    const pl_char_t *item_port, \
			    pl_int_t type)
{
    pl_char_t ip[IPLEN];
    pl_int_t port, sockfd;
    pl_var_t *pv;
    pv = pl_get_conf(pd->domain, item_ip, VAR);
    if( pv==NULL ) {
	pl_log(ERROR, \
	"pl_create_listen_socket(): no item '%s' \
in config file.", item_ip);
    }
    if( pv->type!=STR ) {
	pl_log(ERROR, "pl_create_listen_socket(): \
type of item '%s' is error.", item_port);
    }
    memset(ip, 0, IPLEN);
    strcpy(ip, pv->data.str);
    pv = pl_get_conf(pd->domain, item_port, VAR);
    if( pv==NULL ) {
	pl_log(ERROR, \
	"pl_create_listen_socket(): no item '%s' \
in config file.", item_port);
    }
    if( pv->type!=INT ) {
	pl_log(ERROR, "pl_create_listen_socket(): \
type of item '%s' is error.", item_port);
    }
    port = pv->data.value;
    pl_bind_t *pb;
    pb = pl_create_bind();
    struct sockaddr_in addr;
    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    addr.sin_addr.s_addr = inet_addr(ip);
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if( sockfd<0 ) {
	pl_log(ERROR, \
	"pl_create_listen_socket(): socket return -1. %s.", \
	strerror(errno));
    }
    pl_socket_t *ps = &(pb->s[type>>MOV]);
    pl_set_socket(ps, type, &addr, pb, sockfd);
    pl_setnonblock(ps->sockfd);
    pl_setreuseaddr(ps->sockfd);
    if( bind(ps->sockfd, \
	(struct sockaddr *)&(ps->addr), \
	sizeof(struct sockaddr))<0 )
    {
	pl_log(ERROR, \
	"pl_init_socket(): bind error. %s.", \
	strerror(errno));
    }
    if( listen(ps->sockfd, BACKLOG)<0 ) {
	pl_log(ERROR, \
	"pl_init_socket(): listen error. %s.", \
	strerror(errno));
    }
    pl_add_in_queue(pb);
}

void pl_setnonblock(pl_int_t fd)
{
    pl_int_t flg;
    flg = fcntl(fd, F_GETFL, NULL);
    if( flg<0 ) {
	pl_log(ERROR, \
	"pl_setnonblock(): F_GETFL error. %s.", \
	strerror(errno));
    }
    if( fcntl(fd, F_SETFL, flg | O_NONBLOCK)<0 ) {
	pl_log(ERROR, \
	"pl_setnonblock(): F_SETFL error. %s.", \
	strerror(errno));
    }
}

void pl_setreuseaddr(pl_int_t fd)
{
    pl_int_t val = 1;
    if( setsockopt(fd, SOL_SOCKET, \
	SO_REUSEADDR, &val, sizeof(val))<0 )
    {
	pl_log(ERROR, \
	"pl_setreuseaddr(): setsockopt error. %s.", \
	strerror(errno));
    }
}

void pl_tcp_nodelay(pl_int_t fd)
{
    pl_int_t val = 1;
    if( setsockopt(fd, IPPROTO_TCP, \
	TCP_NODELAY, &val, sizeof(val))<0 )
    {
	pl_log(ERROR, \
	"pl_tcp_nodelay(): setsockopt error. %s.", \
	strerror(errno));
    }
}

/*#######################################
#		pl_bind_t		#
########################################*/
pl_bind_t *pl_create_bind(void)
{
    pl_bind_t *pb;
    pb = pl_alloc(gpq.pool, sizeof(pl_bind_t));
    if( pb==NULL ) {
	pl_log(ERROR, \
	"pl_create_bind(): allocate pl_bind_t error.");
    }
    return pb;
}

void pl_add_in_queue(pl_bind_t *pb)
{
    if( gpq.pb==NULL ) {
	gpq.pb = gpq.pb_tail = pb;
    } else {
	gpq.pb_tail->next = pb;
	pb->prev = gpq.pb_tail;
	gpq.pb_tail = pb;
    }
}

void pl_del_from_queue(pl_bind_t *pb)
{
    if( pb==gpq.pb ) {
	if( pb==gpq.pb_tail ) {
	    gpq.pb = gpq.pb_tail = NULL;
	} else {
	    gpq.pb = pb->next;
	    gpq.pb->prev = NULL;
	}
    } else {
	if( pb==gpq.pb_tail ) {
	    gpq.pb_tail = pb->prev;
	    gpq.pb_tail->next = NULL;
	} else {
	    pb->next->prev = pb->prev;
	    pb->prev->next = pb->next;
	}
    }
    pb->next = pb->prev = NULL;
    if( gpq.rm==NULL ) {
	gpq.rm = gpq.rm_tail = pb;
    } else {
	gpq.rm_tail->next = pb;
	pb->prev = gpq.rm_tail;
	gpq.rm_tail = pb;
    }
}

pl_bind_t *pl_get_bind(void)
{
    return gpq.pb;
}

void pl_clean_socket_memory(void)
{
    pl_bind_t *pb = gpq.rm, *free;
    pl_int_t i;
    while( pb!=NULL ) {
	free = pb;
	pb = pb->next;
	for(i = 0; i<2; i++) {
	    pl_delall_chain_node(&(free->s[i]));
	}
	if( pl_free(free)<0 ) {
	    pl_log(ERROR, \
	    "pl_del_from_queue(): free 'pb' error.");
	}
    }
    gpq.rm = gpq.rm_tail = NULL;
}

/*#######################################
#		pl_socket_t		#
#########################################*/
pl_socket_t *pl_create_socket(void)
{
    pl_socket_t *ps;
    ps = pl_alloc(gpq.pool, sizeof(pl_socket_t));
    if( ps==NULL ) {
	pl_log(ERROR, \
	"pl_create_socket(): allocate pl_socket_t error.");
    }
    return ps;
}

void pl_set_socket(pl_socket_t *ps, pl_int_t type, \
    struct sockaddr_in *addr, pl_bind_t *pb, pl_int_t sockfd)
{
    ps->type = type;
    ps->pb = pb;
    ps->sockfd = sockfd;
    if( addr!=NULL ) {
	memcpy(&(ps->addr), addr, sizeof(struct sockaddr_in));
    }
    if( gettimeofday(&(ps->start), NULL)<0 ) {
	pl_log(EMERGE, "pl_set_socket(): gettimeofday error. %s.", \
	strerror(errno));
    }
}

void pl_del_socket(pl_socket_t *ps)
{
    pl_chain_t *pc, *rm;
    pc = ps->pc;
    while( pc!=NULL ) {
	rm = pc;
	pc = pc->next;
	pl_del_chain_node(ps, rm);
    }
    if( pl_free(ps)<0 ) {
	pl_log(ERROR, \
	"pl_del_socket(): free pl_socket_t error.");
    }
}

pl_socket_t *pl_get_other_socket(pl_socket_t *ps)
{
    return &(ps->pb->s[(ps - ps->pb->s)?0:1]);
}

/*#######################################
#		pl_chain_t		#
#########################################*/
pl_chain_t *pl_create_chain_node(void)
{
    pl_chain_t *pc;
    pc = pl_alloc(gpq.pool, sizeof(pl_chain_t));
    if( pc==NULL ) {
	pl_log(ERROR, \
	"pl_create_chain_node(): allocate pl_chain_t error.");
    }
    return pc;
}

void pl_add_chain_node(void *buf, pl_int_t size, \
		pl_socket_t *ps, pl_chain_t *pc)
{
    pc->buf = pl_alloc(gpq.pool, size);
    if( buf==NULL ) {
	pl_log(ERROR, \
	"pl_add_chain_node(): allocate BUF error.");
    }
    memcpy(pc->buf, buf, size);
    pc->size = size;
    if( ps->pc==NULL ) {
	ps->pc = ps->pc_tail = pc;
    } else {
	ps->pc_tail->next = pc;
	ps->pc_tail = pc;
    }
    ps->nr_buf++;
}

void pl_del_chain_node(pl_socket_t *ps, pl_chain_t *pc)
{
    if( --ps->nr_buf<0 ) {
	pl_log(ERROR, \
	"pl_del_chain_node(): buffer number less than zero.");
    }
    if( ps->pc_tail==ps->pc ) {
	ps->pc_tail = ps->pc = NULL;
    } else {
	ps->pc = pc->next;
    }
    if( pl_free(pc->buf)<0 ) {
	pl_log(ERROR, \
	"pl_del_chain_node(): free chain buf error.");
    }
    if( pl_free(pc)<0 ) {
	pl_log(ERROR, \
	"pl_del_chain_node(): free chain node error.");
    }
}

void pl_delall_chain_node(pl_socket_t *ps)
{
    pl_chain_t *rm, *pc = ps->pc;
    while( pc!=NULL ) {
	rm = pc;
	pc = pc->next;
	pl_del_chain_node(ps, rm);
    }
    ps->pc = ps->pc_tail = NULL;
}

void pl_xchg_chain_node(pl_socket_t *src, \
			pl_socket_t *dest)
{
    if( dest->pc==NULL ) {
	dest->pc = src->pc;
	dest->pc_tail = src->pc_tail;
    } else {
	dest->pc_tail->next = src->pc;
	dest->pc_tail = src->pc_tail;
    }
    src->pc = src->pc_tail = NULL;
    dest->nr_buf += src->nr_buf;
    src->nr_buf = 0;
}
/*#######################################
#	    pl_event_cache_t		#
#########################################*/
void pl_init_cache_stuff(void)
{
    pl_int_t proc = pl_get_proc_type();
    nr_cache_available = CACHESIZE;
    cache_get = NULL;
    cache_put = event_cache;
    if( proc==MASTER ) {
	return ;
    }
    if( gpq.cache_status ) {
	if( signal(SIGALRM, \
	    pl_connection_cache_heartbeat)==SIG_ERR )
	{
	    pl_log(ERROR, \
	    "pl_init_cache_stuff(): signal SIGALRM error.");
	}
	alarm(HBSEC);
    }
}

void pl_clean_all_cache(void)
{
    pl_event_cache_t *pec;
    for(pec = event_cache; \
	pec<event_cache+CACHESIZE; pec++)
    {
	if( pec->s.sockfd ) {
	    close(pec->s.sockfd);
	}
    }
    memset(event_cache, 0, \
	sizeof(pl_event_cache_t)*CACHESIZE);
}

void pl_assign_cache_pointer(pl_int_t flg, \
			pl_event_cache_t *pec)
{
    switch( flg ) {
	case GET:
	    cache_get = pec;
	    return ;
	case PUT:
	    cache_put = pec;
	    return ;
	default:
	    pl_log(ERROR, \
	    "pl_assign_cache_pointer(): no such flag.");
    }
}

pl_event_cache_t *pl_return_cache_pointer(pl_int_t flg)
{
    if( flg==GET )
	return cache_get;
    else if( flg==PUT )
	return cache_put;
    else
	pl_log(ERROR, \
	"pl_return_cache_pointer(): no such flag.");
    return NULL;
}

void pl_next_available_cache(pl_int_t flg)
{
    pl_event_cache_t *scan = event_cache;
    pl_event_cache_t *end = event_cache+CACHESIZE;
    if( flg==GET ) {
	if( cache_get!=NULL ) {
	    scan = cache_get;
	}
	cache_get = NULL;
    } else if( flg==PUT ) {
	if( cache_put!=NULL ) {
	    scan = cache_put;
	}
	cache_put = NULL;
    } else {
	pl_log(ERROR, \
	"pl_next_available_cache(): no such flag.");
    }
    pl_int_t i = 0;
ag: for(; i<CACHESIZE && scan<end; scan++, i++) {
	if( flg==GET ) {
	    if( scan->s.sockfd ) {
		cache_get = scan;
		return ;
	    }
	} else {
	    if( !(scan->s.sockfd) ) {
		cache_put = scan;
		return ;
	    }
	}
    }
    if( scan==end && i!=CACHESIZE ) {
	if( i>CACHESIZE ) {
	    pl_log(ERROR, "pl_next_available_cache(): \
cache_get pointer point to error place.");
	}
	scan = event_cache;
	goto ag;
    }
}

pl_int_t pl_get_connection_cache_status(void)
{
    return gpq.cache_status;
}

void pl_clean_cache_by_server(pl_server_t *srv)
{
    pl_event_cache_t *pec;
    for(pec = event_cache; pec<event_cache+CACHELEN; pec++) {
	if( pec->s.srv==srv ) {
	    close(pec->s.sockfd);
	    memset(pec, 0, sizeof(pl_event_cache_t));
	    if( pec==cache_get ) {
		cache_get = NULL;
	    }
	    if( pec==cache_put ) {
		cache_put = NULL;
	    }
	}
	if( cache_get==NULL && pec->s.sockfd ) {
		cache_get = pec;
	}
	if( cache_put==NULL && !(pec->s.sockfd) ) {
		cache_put = pec;
	}
    }
}

static void
pl_connection_cache_heartbeat(pl_int_t signo)
{
    pl_time_t end = time(NULL);
    pl_event_cache_t *pec;
    for(pec = event_cache; \
	pec<event_cache+CACHESIZE; pec++)
    {
	if( pec->s.sockfd ) {
	    if( pl_check_cache_connection(pec->s.sockfd)<0 || \
		(end - pec->start)>BROKENSEC )
	    {
		close(pec->s.sockfd);
		memset(pec, 0, sizeof(pl_event_cache_t));
	    }
	}
    }
    if( cache_get!=NULL && !(cache_get->s.sockfd) ) {
	pl_next_available_cache(GET);
    }
    if( cache_put==NULL ) {
	pl_next_available_cache(PUT);
    }
    if( signal(SIGALRM, \
	pl_connection_cache_heartbeat)==SIG_ERR )
    {
	pl_log(ERROR, "pl_connection_cache_heartbeat(): \
signal SIGALRM error.");
    }
    alarm(HBSEC);
}

pl_int_t pl_check_cache_connection(pl_int_t fd)
{
    pl_char_t buf[BUFLEN];
    pl_int_t n;
lp: memset(buf, 0, BUFLEN);
    n = read(fd, buf, BUFLEN);
    if( n>0 ) goto lp;
    else if( n<0 && errno==EAGAIN )
	return 0;
    else
	return -1;
}

/*###############################################
#		list for server			#
#################################################*/
void pl_add_sock_list(pl_server_t *srv,pl_socket_t *ps)
{
    pl_sock_list_t *psl;
    psl = pl_alloc(gpq.pool, sizeof(pl_sock_list_t));
    if( psl==NULL )
	pl_log(ERROR, \
	"pl_add_sock_list(): allocate pl_sock_list_t error.");
    psl->ps = ps;
    if( srv->socklist==NULL ) {
	srv->socklist = srv->socktail = psl;
    } else {
	((pl_sock_list_t *)(srv->socktail))->next = psl;
	psl->prev = srv->socktail;
	srv->socktail = psl;
    }
    ps->psl = psl;
}

void pl_del_sock_list(pl_server_t *srv, pl_socket_t *ps)
{
    if( ps->psl==srv->socklist ) {
	if( ps->psl==srv->socktail ) {
	    srv->socklist = srv->socktail = NULL;
	} else {
	    ps->psl->next->prev = NULL;
	    srv->socklist = ps->psl->next;
	}
    } else {	
	if( ps->psl==srv->socktail ) {
	    ps->psl->prev->next = NULL;
	    srv->socktail = ps->psl->prev;
	} else {
	    ps->psl->next->prev = ps->psl->prev;
	    ps->psl->prev->next = ps->psl->next;
	}
    }
    if( pl_free(ps->psl)<0 ) {
	pl_log(ERROR, \
	"pl_del_sock_list(): free pl_sock_list_t error.");
    }
    ps->psl = NULL;
}

void pl_del_all_sock_list(pl_server_t *srv)
{
    pl_sock_list_t *psl, *rm;
    pl_socket_t *other;
    psl = (pl_sock_list_t *)(srv->socklist);
    while( psl!=NULL ) {
	rm = psl;
	psl = psl->next;
	other = pl_get_other_socket(rm->ps);
	if( other->status!=DEAD ) {
	    pl_ctl_event(other, \
	    EPOLLOUT|EPOLLONESHOT|EPOLLET, MOD);
	}
	pl_close_socket(rm->ps, 0);
    }
    srv->socklist = srv->socktail = NULL;
}

/*void pl_print_sock(void)
{
	pl_bind_t *pb;
	pl_chain_t *pc;
	pl_int_t i;
	for(pb = gpq.pb; pb!=NULL; pb = pb->next) {
		for(i = 0; i<2; i++) {
			printf("PID:%d Sockfd[%d]:%d\n", getpid(), i, pb->s[i].sockfd);
			printf("\ttype:%x\n", pb->s[i].type);
			printf("\tnr_buf:%x\n", pb->s[i].nr_buf);
			printf("\tstatus:%x\n", pb->s[i].status);
			for(pc = pb->s[i].pc; pc!=NULL; pc = pc->next) {
				printf("\tContent:[%s]\n", (char *)pc->buf);
				printf("\tsize:%d\n", pc->size);
				printf("\tw_size:%d\n", pc->w_size);
			}
		}
		printf("\n");
	}
}*/

