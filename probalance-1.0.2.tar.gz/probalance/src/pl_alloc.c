
/*
 * Copyright (C) Niklaus F.Schen.
 */

#include"pl_alloc.h"
#include<stdio.h>
/*local declarations*/
static void pl_fill_information(pl_list_t *list, \
pl_block_t *blk, void *buf, unsigned long long size);
static unsigned long pl_check_sum(void *buf);
static pl_block_t *pl_create_block(int size);

pl_pool_t *pl_create_pool(void)
{
    pl_pool_t *pool = calloc(1, sizeof(pl_pool_t));
    pl_list_t *pl, *plend = pool->list + sizeof(long *)*8;
    unsigned long long i = 1, off = 0;
    for(pl = pool->list; pl<plend; pl++) {
        pl->size = i<<off; off++;
    }
    return pool;
}
#ifndef __DEBUG
void *pl_alloc(pl_pool_t *pool, unsigned long size)
{
    if( pool==NULL || !size) {
        return NULL;
    }
    unsigned long long blk_size = 1, index = 0;
    while( size>blk_size ) {
        blk_size <<= 1; index++;
    }
    pl_block_t *pblk;
    pl_list_t *pl = &(pool->list)[index];
    pblk = pl->free;
    if( pblk==NULL ) {
        pblk = pl_create_block(blk_size);
        if( pblk==NULL ) return NULL;	
        pl->nr_free++;
    }
    pl->free = pblk->next;
    if( pl->free!=NULL ) pl->free->prev = NULL;
    pblk->next = pl->used;
    pblk->prev = NULL;
    if( pl->used!=NULL ) pl->used->prev = pblk;
    pl->used = pblk;
    pl->nr_free--;
    pl->nr_used++;
    pl_fill_information(pl, pblk, pblk->blk, pl->size);
    return ((pblk->blk)+sizeof(char *)*2);
}
#else
void *pl_alloc(pl_pool_t *pool, unsigned long size)
{
    void *ptr = calloc(1, size);
    return ptr;
}
#endif

static void pl_fill_information(pl_list_t *list, \
pl_block_t *blk, void *buf, unsigned long long size)
{
    *((unsigned long *)buf) = (unsigned long)list;
    *((unsigned long *)(buf+sizeof(unsigned long))) = (unsigned long)blk;
    *((unsigned long *)(buf+2*sizeof(char *)+size)) = pl_check_sum(buf);
}

static unsigned long pl_check_sum(void *buf)
{
    unsigned long sum = 0, i;
    char *p;
    for(p = (char *)buf; \
	p<(char *)(buf+sizeof(char *)*2); \
	p++)
    {
	for(i = 0; i<8; i++) {
	    if( (1<<i)&(*p) ) {
		sum++;
	    }
	}
    }
    return sum;
}

static pl_block_t *pl_create_block(int size)
{
    if( size<=0 ) {
	return NULL;
    }
    pl_block_t *pb = calloc(1, sizeof(pl_block_t));
    if( pb==NULL ) {
	return NULL;
    }
    pb->blk = calloc(1, size+3*sizeof(char *));
    if( pb->blk==NULL ) {
	return NULL;
    }
    return pb;
}

#ifndef __DEBUG
int pl_free(void *ptr)
{
    unsigned long checksum = pl_check_sum(ptr-2*sizeof(char *));
    pl_list_t *pl = *(pl_list_t **)(ptr-2*sizeof(char *));
    pl_block_t *pb = *(pl_block_t **)(ptr-sizeof(char *));
    if( checksum!=*(unsigned long *)(ptr+pl->size) ) return -1;
    pl->nr_used--;
    if( pb->prev==NULL ) {
	if( pb->next==NULL ) {
	    pl->used = NULL;
	} else {
	    pl->used = pb->next;
	    pl->used->prev = NULL;
	}
    } else {
	if( pb->next==NULL ) {
	    pb->prev->next = NULL;
	} else {
	    pb->prev->next = pb->next;
	    pb->next->prev = pb->prev;
	}
    }
    if( pl->nr_free<LIMIT ) {
	pb->prev = NULL;
	pb->next = pl->free;
	pl->free = pb;
	memset(pb->blk, 0, pl->size+3*sizeof(char *));
	pl->nr_free++;
    } else {
	free(pb->blk);
	free(pb);
    }
    return 0;
}
#else
int pl_free(void *ptr)
{
    free(ptr);
    return 0;
}
#endif

void pl_destory_pool(pl_pool_t *pool)
{
    pl_block_t *pb, *rm_blk;
    pl_list_t *pl, *plend = pool->list + sizeof(long *)*8;
    for(pl = pool->list; pl<plend; pl++) {
	pb = pl->free;
	while( pb!=NULL ) {
	    free(pb->blk);
	    rm_blk = pb;
	    pb = pb->next;
	    free(rm_blk);
	}
	pb = pl->used;
	while( pb!=NULL ) {
	    free(pb->blk);
	    rm_blk = pb;
	    pb = pb->next;
	    free(rm_blk);
	}
    }
    free(pool);
}

void pl_pool_print(pl_pool_t *pool)
{
    pl_list_t *pl, *plend = pool->list + sizeof(long *)*8;
    pl_block_t *blk;
    int cnt;
    for(pl = pool->list; pl<plend; pl++) {
        printf("size:%llu  free:%llu  used:%llu\n", pl->size, pl->nr_free, pl->nr_used);
        for(blk = pl->used, cnt = 0; blk!=NULL; blk = blk->next, cnt++) ;
        printf("Actual used number:%d\n", cnt);
        for(blk = pl->free, cnt = 0; blk!=NULL; blk = blk->next, cnt++) ;
        printf("Actual free number:%d\n\n", cnt);
    }
}

