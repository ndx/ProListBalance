
/*
 * Copyright (C) Niklaus F.Schen.
 */

#ifndef __PL_ROUND_ROBIN
#define __PL_ROUND_ROBIN

#include"pl_server.h"

pl_server_t *round_robin(pl_server_t *srvlist, \
			pl_algorithm_data_t *data);
#endif

