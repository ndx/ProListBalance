
/*
 * Copyright (C) Niklaus F.Schen.
 */

#include"pl_statistics.h"
#include"pl_log.h"
#include<string.h>
/*local function declarations*/
	/*--------for pl_stat_ctl()------*/
static void
pl_stat_in(pl_statinfo_t *pst, \
		pl_ullong_t val);
static void
pl_stat_out(pl_statinfo_t *pst, \
		pl_ullong_t val);
static void
pl_stat_time(pl_statinfo_t *pst, \
		pl_ullong_t val);
static void
pl_stat_weight(pl_statinfo_t *pst, \
		pl_ullong_t val);
static void
pl_stat_current_weight(pl_statinfo_t *pst, \
		pl_ullong_t val);
static void
pl_stat_down(pl_statinfo_t *pst, \
		pl_ullong_t val);
static void
pl_stat_idle(pl_statinfo_t *pst, \
		pl_ullong_t val);
static void
pl_stat_current_connections(pl_statinfo_t *pst, \
				pl_ullong_t val);
static void
pl_stat_nr_notrans(pl_statinfo_t *pst, \
			pl_ullong_t val);
static void
pl_stat_sum_connections(pl_statinfo_t *pst, \
			pl_ullong_t val);
static void
pl_stat_failed_connections(pl_statinfo_t *pst, \
			pl_ullong_t val);
/*--------for pl_get_stat_value()------*/
static void pl_vin(pl_statinfo_t *pst, \
		void *val, pl_int_t size);
static void pl_vout(pl_statinfo_t *pst, \
		void *val, pl_int_t size);
static void pl_vmaxind(pl_statinfo_t *pst, \
		void *val, pl_int_t size);
static void pl_vmaxoutd(pl_statinfo_t *pst, \
		void *val, pl_int_t size);
static void pl_vmintimepc(pl_statinfo_t *pst, \
		void *val, pl_int_t size);
static void pl_vmaxtimepc(pl_statinfo_t *pst, \
		void *val, pl_int_t size);
static void pl_valltime(pl_statinfo_t *pst, \
		void *val, pl_int_t size);
static void pl_vnotrans(pl_statinfo_t *pst, \
		void *val, pl_int_t size);
static void pl_vsum(pl_statinfo_t *pst, \
		void *val, pl_int_t size);
static void pl_vcurrent(pl_statinfo_t *pst, \
		void *val, pl_int_t size);
static void pl_vfailed(pl_statinfo_t *pst, \
		void *val, pl_int_t size);
static void pl_vweight(pl_statinfo_t *pst, \
		void *val, pl_int_t size);
static void pl_vcweight(pl_statinfo_t *pst, \
		void *val, pl_int_t size);
static void pl_vdown(pl_statinfo_t *pst, \
		void *val, pl_int_t size);
static void pl_vidle(pl_statinfo_t *pst, \
		void *val, pl_int_t size);
static void pl_vname(pl_statinfo_t *pst, \
		void *val, pl_int_t size);

/*static variables*/
static pl_statis_t
valtable[NRVALUE] = {
pl_stat_in, \
pl_stat_current_weight, \
pl_stat_out, \
pl_stat_time, pl_stat_weight, \
pl_stat_down, pl_stat_idle};

static pl_statis_t
inctable[NRINC] = {
pl_stat_current_connections, \
pl_stat_nr_notrans, \
pl_stat_sum_connections, \
pl_stat_failed_connections};

static pl_statis_t
dectable[NRDEC] = {
pl_stat_current_connections, \
pl_stat_current_weight
};

static pl_char_t error[] = \
	"Data overflow. Please use \
command 'clear' to flush all recorders.";

static pl_statdata_t
datatable[] = {
pl_vin, pl_vout, pl_vmaxind, \
pl_vmaxoutd, pl_vmintimepc, \
pl_vmaxtimepc, pl_valltime, \
pl_vnotrans, pl_vsum, pl_vcurrent,\
pl_vfailed, pl_vweight, pl_vcweight, \
pl_vdown, pl_vidle, pl_vname
};



/*##########################################################
#	void pl_stat_ctl() and its related functions.	   #
############################################################*/
void pl_stat_ctl(pl_statinfo_t *pst, pl_int_t item, \
		pl_int_t type, pl_ullong_t val)
{
    switch( type ) {
    case VALUE:
	if( item>NRVALUE ) {
	    pl_log(EMERGE, "pl_stat_ctl(): item '%d' \
out of VALUE array length.", item);
	}
	(valtable[item])(pst, val);
	break;
    case INC:
	if( item>NRINC ) {
	    pl_log(EMERGE, "pl_stat_ctl(): item '%d' \
out of INC array length.", item);
	}
	(inctable[item])(pst, INC);
	break;
    case DEC:
	if( item>NRDEC ) {
	    pl_log(EMERGE, "pl_stat_ctl(): item '%d' \
out of DEC array length.", item);
	}
	(dectable[item])(pst, DEC);
	break;
    default:
	pl_log(EMERGE, "pl_stat_ctl(): no such type.");
    }
}

static void
pl_stat_in(pl_statinfo_t *pst, pl_ullong_t val)
{
    if( pst->in+val>(pl_ullong_t)~0 ) {
	pl_log(DEBUG, "pl_stat_in(): %s", error);
	pst->in = 0;
    }
    pst->in += val;
    if( pst->max_in_data<val )
	pst->max_in_data = val;
}

static void
pl_stat_out(pl_statinfo_t *pst, pl_ullong_t val)
{
    if( pst->out+val>(pl_ullong_t)~0 ) {
	pl_log(DEBUG, "pl_stat_in(): %s", error);
	pst->out = 0;
    }
    pst->out += val;
    if( pst->max_out_data<val )
	pst->max_out_data = val;
}

static void
pl_stat_time(pl_statinfo_t *pst, pl_ullong_t val)
{
    if( pst->all_time+val>(pl_ullong_t)~0 ) {
	pl_log(DEBUG, "pl_stat_in(): %s", error);
	pst->all_time = 0;
    }
    pst->all_time += val;
    if( pst->min_time_per_connection!=0 && \
	pst->min_time_per_connection>val )
	pst->min_time_per_connection = val;
    if( pst->max_time_per_connection<val )
	pst->max_time_per_connection = val;
}

static void
pl_stat_weight(pl_statinfo_t *pst, pl_ullong_t val)
{
    pst->weight = val;
}

static void
pl_stat_current_weight(pl_statinfo_t *pst, \
			    pl_ullong_t val)
{
    if( val==DEC ) {
	pst->current_weight--;
    } else {
	pst->current_weight = val;
    }
}

static void
pl_stat_down(pl_statinfo_t *pst, pl_ullong_t val)
{
    pst->down = val;
}

static void
pl_stat_idle(pl_statinfo_t *pst, pl_ullong_t val)
{
    pst->idle = val;
}

static void
pl_stat_current_connections(pl_statinfo_t *pst, \
				pl_ullong_t val)
{
    if( val==DEC ) {
	pst->current_connections--;
    } else {
	pst->current_connections++;
    }
}

static void
pl_stat_nr_notrans(pl_statinfo_t *pst, \
			pl_ullong_t val)
{
    if( pst->nr_notrans==(pl_ullong_t)~0 ) {
	pl_log(DEBUG, "pl_stat_in(): %s", error);
	pst->nr_notrans = 0;
    }
    pst->nr_notrans++;
}

static void
pl_stat_sum_connections(pl_statinfo_t *pst, \
			pl_ullong_t val)
{
    if( pst->sum_connections==(pl_ullong_t)~0 ) {
	pl_log(DEBUG, "pl_stat_in(): %s", error);
	pst->sum_connections = 0;
    }
    pst->sum_connections++;
}

static void
pl_stat_failed_connections(pl_statinfo_t *pst, \
				pl_ullong_t val)
{
    if( pst->failed_connections==(pl_ullong_t)~0 ) {
	pl_log(DEBUG, "pl_stat_in(): %s", error);
	pst->failed_connections = 0;
    }
    pst->failed_connections++;
}

/*##########################################################
#	void pl_get_stat_value() and its related functions.#
############################################################*/
void pl_get_stat_value(pl_statinfo_t *pst, \
	pl_int_t var, void *val, pl_int_t size)
{
    if( val==NULL || size<=0 )
	return;
    (datatable[var])(pst, val, size);
}

static void pl_vin(pl_statinfo_t *pst, \
		void *val, pl_int_t size)
{
    if( size==sizeof(pst->in) )
	memcpy(val, &(pst->in), size);
}

static void pl_vout(pl_statinfo_t *pst, \
		void *val, pl_int_t size)
{
    if( size==sizeof(pst->out) )
	memcpy(val, &(pst->out), size);
}

static void pl_vmaxind(pl_statinfo_t *pst, \
		void *val, pl_int_t size)
{
    if( size==sizeof(pst->max_in_data) )
	memcpy(val, &(pst->max_in_data), size);
}

static void pl_vmaxoutd(pl_statinfo_t *pst, \
		void *val, pl_int_t size)
{
    if( size==sizeof(pst->max_out_data) )
	memcpy(val, &(pst->max_out_data), size);
}

static void pl_vmintimepc(pl_statinfo_t *pst, \
		void *val, pl_int_t size)
{
    if( size==sizeof(pst->min_time_per_connection) )
	memcpy(val, &(pst->min_time_per_connection), size);
}

static void pl_vmaxtimepc(pl_statinfo_t *pst, \
			void *val, pl_int_t size)
{
    if( size==sizeof(pst->max_time_per_connection) )
	memcpy(val, &(pst->max_time_per_connection), size);
}

static void pl_valltime(pl_statinfo_t *pst, \
			void *val, pl_int_t size)
{
    if( size==sizeof(pst->all_time) )
	memcpy(val, &(pst->all_time), size);
}

static void pl_vnotrans(pl_statinfo_t *pst, \
			void *val, pl_int_t size)
{
    if( size==sizeof(pst->nr_notrans) )
	memcpy(val, &(pst->nr_notrans), size);
}

static void pl_vsum(pl_statinfo_t *pst, \
		void *val, pl_int_t size)
{
    if( size==sizeof(pst->sum_connections) )
	memcpy(val, &(pst->sum_connections), size);
}

static void pl_vcurrent(pl_statinfo_t *pst, \
		    void *val, pl_int_t size)
{
    if( size==sizeof(pst->current_connections) )
	memcpy(val, &(pst->current_connections), size);
}

static void pl_vfailed(pl_statinfo_t *pst, \
			void *val, pl_int_t size)
{
    if( size==sizeof(pst->failed_connections) )
	memcpy(val, &(pst->failed_connections), size);
}

static void pl_vweight(pl_statinfo_t *pst, \
		    void *val, pl_int_t size)
{
    if( size==sizeof(pst->weight) )
	memcpy(val, &(pst->weight), size);
}

static void pl_vcweight(pl_statinfo_t *pst, \
			void *val, pl_int_t size)
{
    if( size==sizeof(pst->current_weight) )
	memcpy(val, &(pst->current_weight), size);
}

static void pl_vdown(pl_statinfo_t *pst, \
		void *val, pl_int_t size)
{
    if( size==sizeof(pst->down) )
	memcpy(val, &(pst->down), size);
}

static void pl_vidle(pl_statinfo_t *pst, \
		void *val, pl_int_t size)
{
    if( size==sizeof(pst->idle) )
	memcpy(val, &(pst->idle), size);
}

static void pl_vname(pl_statinfo_t *pst, \
		void *val, pl_int_t size)
{
    if( size==STINAME )
	memcpy(val, pst->name, size);
}

/*#######################################################
#		pl_init_stat_min_value()		#
########################################################*/
void pl_init_stat_min_value(pl_statinfo_t *pst)
{
    pst->min_time_per_connection = ~0;
}

